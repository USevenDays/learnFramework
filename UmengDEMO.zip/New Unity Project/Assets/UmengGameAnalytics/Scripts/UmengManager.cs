﻿
using UnityEngine;
using System.Collections;
using Umeng;
/// <summary>
/// Umeng管理类，建议挂在不会销毁的摄像机上
/// </summary>
public class UmengManager : MonoBehaviour
{
	
	void Awake()
	{
		DontDestroyOnLoad (transform.gameObject);
	}
	
	#if UNITY_ANDROID

    /// <summary>
    /// 控制友盟监控的开始结束
    /// </summary>
    /// <param name="isPause"></param>
	void OnApplicationPause(bool isPause)
	{
		
		//Debug.Log("Umeng:OnApplicationPause" + isPause);
		if (isPause){
			//Debug.Log("Umeng:----onPause");
			GA.onPause();
		}
		else{
			//Debug.Log("Umeng:----onResume");
			GA.onResume();
		}
		
	}
    /// <summary>
    /// 关闭Umeng监控
    /// </summary>
	void OnApplicationQuit()
	{
		//Debug.Log("Umeng:OnApplicationQuit");
		GA.onKillProcess();
	}
	
	#endif
	
	
	
	
	
}
