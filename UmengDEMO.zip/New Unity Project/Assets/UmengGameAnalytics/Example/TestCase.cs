﻿using UnityEngine;
using Umeng;
using System.Runtime.InteropServices;

/// <summary>
/// 测试会发生用户信息和一个事件
/// </summary>
public class TestCase : MonoBehaviour {

	void Start () {

		//JSONNode N = new Json
		//N[1] = "Hello world";
		//N[1] = "string";
		//Debug.Log("JSON: " + N.ToString());

        ////设置Umeng Appkey
        //GA.StartWithAppKeyAndChannelId("593e404d4544cb33e80005d7", "App Store");

        ////调试时开启日志
        //GA.SetLogEnabled (true);

        //GA.SetLogEncryptEnabled(true);


        //GA.ProfileSignIn("fkdafjadklfjdklf");//

        //GA.ProfileSignIn("jfkdajfdakfj","app strore");
	
        //print ("GA.ProfileSignOff();");

        //GA.ProfileSignOff();

	}

	void OnGUI() {

        //if (GUI.Button(new Rect(Screen.width/2, Screen.height/2, 300, 100), "未集成自定义事件"))
        //{
        //    GA.SetUserLevel (2);
        //    string[] arrayC21 = new string[3];
        //    arrayC21[0] = "one";
        //    arrayC21[1] = "1234567890123456000";
        //    arrayC21[2] = "one";
        //    GA.Event(arrayC21,2,"label");
        //    //GA.GetDeviceInfo ();
        //}
    }
}


