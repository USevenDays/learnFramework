﻿using UnityEngine;
using Umeng;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;
using UnityEngine.UI;


public class Example : MonoBehaviour
{

    public static Example Instance;

    public Text text;

    void Start()
    {
        //到友盟 获取app key
        GA.StartWithAppKeyAndChannelId("593e404d4544cb33e80005d7", "App Store");

        //调试时开启日志 发布时设置为false
        GA.SetLogEnabled(true);

        GA.SetLogEncryptEnabled(true);
        //玩家登陆
        GA.ProfileSignIn("ssssssssssss");//
        //玩家第三方登录
        GA.ProfileSignIn("aaaaaaaaaaaa", "App Store");

        GA.ProfileSignIn("xiguage", "21");
        GA.ProfileSignIn("xingjing", "22");

        print("GA.ProfileSignOff();");

        GA.ProfileSignOff();

    }
    /// <summary>
    /// 显示操作
    /// </summary>
    /// <param name="a"></param>
    public void TestPay(string a)
    {
        text.text = a;
    }

    int level = 1;
    void OnGUI()
    {
        if (GUI.Button(new Rect(Screen.width / 2, Screen.height / 2, 300, 100), "未集成自定义事件"))
        {
            GA.SetUserLevel(2);
            string[] arrayC21 = new string[3];
            arrayC21[0] = "one";
            arrayC21[1] = "1234567890123456000";
            arrayC21[2] = "one";
            GA.Event(arrayC21, 2, "label");
            //GA.GetDeviceInfo ();
        }
        /////第一列
        if (GUI.Button(new Rect(10, 10, 200, 50), "支付宝648买屠龙刀"))
        {
            GA.Pay(648, GA.PaySource.支付宝,"21001",2,324);
            TestPay("支付宝648买屠龙刀");
        }
        if (GUI.Button(new Rect(10,60, 200, 50), "玩家支付宝充值324"))
        {
            GA.Pay(324,GA.PaySource.支付宝,6000);
            TestPay("玩家充值324-6000钻");
        }
        if (GUI.Button(new Rect(10,120 , 200, 50), "600W买6火神炮"))
        {
            GA.Buy("21002",5, 6000000);
            TestPay("600W买6火神炮");
        }
        if (GUI.Button(new Rect(10, 180, 200, 50), "使用中强化石5"))
        {
            GA.Use("gem_2", 5, 1);
            TestPay("使用中强化石5");
        }
        if (GUI.Button(new Rect(10, 230, 200, 50), "进入关卡21001寻宝1"))
        {
            GA.StartLevel("21001");
            Invoke("Ha2", 2);//2S通过
            Invoke("Ha3", 5);//5S未通过
            TestPay("进入关卡21001寻宝1");
        }
        if (GUI.Button(new Rect(10, 280, 200, 50), "玩家等级统计"))
        {
            GA.SetUserLevel(99);
            TestPay("玩家等级99");
        }
        if (GUI.Button(new Rect(10, 330, 200, 50), "系统发5000金币"))
        {
            GA.Bonus(5000,GA.BonusSource.系统奖励);
            GA.Bonus(5000, GA.BonusSource.活动任务获得);
            TestPay("系统发5000金币,活动再送5000");
        }
        if (GUI.Button(new Rect(10, 380, 200, 50), "天上掉下秘籍"))
        {
            GA.Bonus("21004",2,99999,GA.BonusSource.老爸给的);
            TestPay("天上掉下秘籍");
        }
        if (GUI.Button(new Rect(10, 430, 200, 50), "点击商船"))
        {
            GA.Event("100001");
            TestPay("点击商船");
        }
        if (GUI.Button(new Rect(10, 480, 200, 50), "点击好友"))
        {
            GA.Event("100004","shejiao");
            TestPay("点击好友");
        }
        if (GUI.Button(new Rect(10,530, 200, 50), "开启5秒商城"))
        {
            //打印
            GA.PageBegin("MainPanel");
            Invoke("Ha1",5);
            TestPay("打开商城面板");
        }

        ////////第二列
        if (GUI.Button(new Rect(210, 10, 200, 50), "在线参数"))
        {
            //打印
            string DeciceInfo = GA.GetDeviceInfo();
            TestPay(DeciceInfo);
        }
        if (GUI.Button(new Rect(210, 60, 200, 50), "点击舰队"))
        {
            GA.Event("100002");
            TestPay("点击商船");
        }
        if (GUI.Button(new Rect(210, 120, 200, 50), "点击船员"))
        {
            GA.Event("100003");
            TestPay("点击商船");
        }
    }

    void Ha1() {
        GA.PageEnd("MainPanel");
    }
    void Ha2()
    {
        GA.FinishLevel("21001");
    }
    void Ha3()
    {
        GA.FailLevel("21001");
    }
}


